export default {
  mac: /Macintosh/.test(navigator.userAgent),
  iosdevice: /(iPad)|(iPhone)/.test(navigator.userAgent)
}
