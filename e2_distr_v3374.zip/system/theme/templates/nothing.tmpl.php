<?php if (@$content['nothing']) { ?>
<div class="e2-nothing" id="e2-nothing-message">
<p><?=@$content['nothing']?></p>
</div>
<?php } ?>
