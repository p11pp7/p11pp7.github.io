License: http://blogengine.ru/get/

To each copy of Aegea applies the license which is the latest at the moment of installation or update.

Thanks to
Igor Adamenko for local autosaving and much more, https://igoradamenko.com/
Romam Parpalak for “Rose” search engine, https://written.ru/
Ilya Straykov for help with version 2.5 development, http://straykov.ru/
Artem Polikarpov for brilliant Fotorama, http://fotorama.io/
Ivan Sagalaev for Highlight.js, http://highlightjs.org/
Murat Schidakov for help with tags entry UI implementation and support
Igor Vasilkovsky for the backup system implementation
Ivan Scholokov and Victor Koreysha for integration social networks into comments

and also to
Alexander Karpinsky, Artem Sapegin, Maxim Ilyahov, Dmitry Kirsanov, Evgeny Stepanischev, Julia Shabunio, Dmitry Smirnov

- - - - -

Лицензия: http://blogengine.ru/get/

К каждой инсталляции Эгеи применима та лицензия, которая была самой свежей на момент установки или последнего обновления.

Спасибо
Игорю Адаменко за локальное автосохранение и много чего ещё, https://igoradamenko.com/
Роману Парпалаку за движок поиска «Роза», https://written.ru/
Илье Страйкову за помощь в разработке версии 2.5, http://straykov.ru/
Артёму Поликарпову за прекрасную Фотораму, http://fotorama.io/
Ивану Сагалаеву за Хайлайт, http://highlightjs.org/
Мурату Шидакову за помощь с интерфейсом ввода тегов
Игорю Васильковскому за реализацию системы бекапов
Ивану Щолокову и Виктору Корейше за интеграцию с соцсетями в комментариях

а также
Саше Карпинскому, Артёму Сапегину, Максиму Ильяхову, Диме Кирсанову, Жене Степанищеву, Юлии Шабунио, Диме Смирнову