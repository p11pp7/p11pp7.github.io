<?php return array (

  'index' => 11,

  'display_name' => array (
    'en' => 'Acute',
    'ru' => 'Акут',
    'uk' => 'Акут',
  ),

  'colors' => array (
    'background' => '#fff',
    'headings' => '#000',
    'text' => '#6b7a76',
    'link' => '#213fff',
  ),

  'based_on' => 'plain',
  'meta_viewport' => 'width=device-width, initial-scale=1',

); ?>