<?php return array (

  // 'display_name' => 'Embeddedable',
  // 'meta_viewport' => 'width=device-width, initial-scale=1',
  // 'global_styles' => '../css/main.css',

); ?>