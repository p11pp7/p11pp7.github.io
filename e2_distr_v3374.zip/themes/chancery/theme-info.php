<?php return array (

  'index' => 17,

  'display_name' => array (
    'en' => 'Chancery',
    'ru' => 'Ченсери',
    'uk' => 'Ченсері',
  ),

  'colors' => array (
    'background' => '#faebd2',
    'headings' => '#000',
    'text' => '#000',
    'link' => '#3d6077',
  ),

  'based_on' => 'plain',
  'meta_viewport' => 'width=device-width, initial-scale=1',

); ?>